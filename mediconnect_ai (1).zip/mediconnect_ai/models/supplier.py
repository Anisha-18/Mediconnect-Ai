from models import db

class Supplier(db.Model):
    __tablename__ = "suppliers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True)
    rating = db.Column(db.Float, nullable=False, default=4.0)
    lead_time_days = db.Column(db.Integer, nullable=False, default=3)
    price_index = db.Column(db.Float, nullable=False, default=1.0)
    compliance_score = db.Column(db.Float, nullable=False, default=90.0)