from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

from models.user import User
from models.hospital import Hospital
from models.inventory import Inventory
from models.supplier import Supplier
from models.purchase_order import PurchaseOrder
from models.alert import Alert
from models.billing import Billing
from models.bill_item import BillItem