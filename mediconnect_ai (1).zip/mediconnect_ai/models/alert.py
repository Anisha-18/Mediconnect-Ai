from datetime import datetime
from models import db

class Alert(db.Model):
    __tablename__ = "alerts"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(20), nullable=False, default="Info")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    hospital_id = db.Column(db.Integer, db.ForeignKey("hospitals.id"), nullable=False)