from models import db

class Hospital(db.Model):
    __tablename__ = "hospitals"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    city = db.Column(db.String(80), nullable=False)
    node_name = db.Column(db.String(80), nullable=False)

    users = db.relationship("User", backref="hospital", lazy=True)
    inventory_items = db.relationship("Inventory", backref="hospital", lazy=True)
    purchase_orders = db.relationship("PurchaseOrder", backref="hospital", lazy=True)
    alerts = db.relationship("Alert", backref="hospital", lazy=True)
    billings = db.relationship("Billing", backref="hospital", lazy=True)