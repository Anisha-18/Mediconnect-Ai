from datetime import datetime, date
from models import db

class Inventory(db.Model):
    __tablename__ = "inventory"

    id = db.Column(db.Integer, primary_key=True)
    medicine = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(80), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    reorder_level = db.Column(db.Integer, nullable=False, default=50)
    forecast_next_week = db.Column(db.Integer, nullable=False, default=0)

    mfg_date = db.Column(db.Date, nullable=True)
    expiry_date = db.Column(db.Date, nullable=True)

    batch_no = db.Column(db.String(80), nullable=True)
    supplier_name = db.Column(db.String(120), nullable=True)
    counterfeit_risk = db.Column(db.String(30), nullable=False, default="Low")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    hospital_id = db.Column(db.Integer, db.ForeignKey("hospitals.id"), nullable=False)

    @property
    def expiry_days(self):
        if not self.expiry_date:
            return None
        return (self.expiry_date - date.today()).days