from datetime import datetime
from models import db

class PurchaseOrder(db.Model):
    __tablename__ = "purchase_orders"

    id = db.Column(db.Integer, primary_key=True)
    medicine = db.Column(db.String(150), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    supplier_name = db.Column(db.String(120), nullable=False)
    priority = db.Column(db.String(30), nullable=False, default="Low")
    status = db.Column(db.String(30), nullable=False, default="Generated")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    hospital_id = db.Column(db.Integer, db.ForeignKey("hospitals.id"), nullable=False)