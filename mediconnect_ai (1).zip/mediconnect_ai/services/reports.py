from datetime import datetime, date

def build_weekly_report(items, bills=None):
    bills = bills or []
    low_stock = [i for i in items if i.stock < i.reorder_level]
    near_expiry = [i for i in items if i.expiry_date and (i.expiry_date - date.today()).days <= 2]
    risky = [i for i in items if i.counterfeit_risk != "Low"]

    total_billed = sum(b.total_amount for b in bills) if bills else 0.0

    text = f"""
MediConnect AI Weekly Healthcare Supply Report
Generated On: {datetime.now().strftime("%d-%m-%Y %H:%M")}

1. Summary
Total medicine records monitored: {len(items)}
Low stock records: {len(low_stock)}
Near expiry within 2 days: {len(near_expiry)}
Counterfeit watch items: {len(risky)}
Total patient billing amount: Rs. {total_billed:.2f}

2. Key Observations
- Billing automatically reduces medicine stock.
- Dashboard is updated using live polling APIs.
- Medicines nearing expiry in 2 days are escalated as alerts.
- Stockout and expiry conditions can trigger AI-supported procurement actions.

3. Recommended Actions
- Generate purchase orders for below-threshold medicines.
- Isolate or redistribute near-expiry medicines.
- Audit suspicious packaging uploads.
- Continue multilingual query support for supply teams.

4. Strategic Outlook
The combined federated, billing-aware, and AI-assisted workflow improves operational visibility and keeps hospital inventory synchronized.
""".strip()

    return {
        "generated_at": datetime.now().strftime("%d %b %Y, %I:%M %p"),
        "report_text": text,
        "low_stock": low_stock,
        "near_expiry": near_expiry,
        "risky": risky,
        "total_billed": total_billed
    }