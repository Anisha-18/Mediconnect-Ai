DRUG_INFO = {
    "paracetamol": {
        "generic_name": "Paracetamol",
        "uses": "Used for fever and mild to moderate pain.",
        "who_can_take": "Usually used by adults and children when prescribed in correct dose.",
        "avoid": "Use carefully in severe liver disease.",
        "category": "Analgesic / Antipyretic"
    },
    "insulin glargine": {
        "generic_name": "Insulin Glargine",
        "uses": "Used to control blood sugar in diabetes.",
        "who_can_take": "Used by diabetic patients as prescribed by a doctor.",
        "avoid": "Use carefully in patients with recurrent hypoglycemia without supervision.",
        "category": "Antidiabetic"
    },
    "amoxicillin": {
        "generic_name": "Amoxicillin",
        "uses": "Used for bacterial infections such as throat, ear, chest, and urinary infections.",
        "who_can_take": "Can be used by adults and children under medical advice.",
        "avoid": "Avoid in penicillin allergy.",
        "category": "Antibiotic"
    },
    "ceftriaxone": {
        "generic_name": "Ceftriaxone",
        "uses": "Used for serious bacterial infections.",
        "who_can_take": "Used in hospital setting under doctor supervision.",
        "avoid": "Avoid in some severe allergy cases and specific neonatal conditions.",
        "category": "Injectable Antibiotic"
    },
    "atorvastatin": {
        "generic_name": "Atorvastatin",
        "uses": "Used to reduce cholesterol and cardiovascular risk.",
        "who_can_take": "Used by adults as prescribed by a doctor.",
        "avoid": "Avoid in active liver disease and pregnancy unless specifically advised.",
        "category": "Lipid-lowering agent"
    },
    "metformin": {
        "generic_name": "Metformin",
        "uses": "Used to control blood sugar in type 2 diabetes.",
        "who_can_take": "Usually used by adults with diabetes under medical advice.",
        "avoid": "Use carefully in severe kidney disease.",
        "category": "Antidiabetic"
    },
    "azithromycin": {
        "generic_name": "Azithromycin",
        "uses": "Used for bacterial infections of respiratory tract, skin, and some other infections.",
        "who_can_take": "Used by adults and children as prescribed.",
        "avoid": "Use carefully in some cardiac rhythm disorders.",
        "category": "Antibiotic"
    },
    "oral rehydration salts": {
        "generic_name": "ORS",
        "uses": "Used to prevent and treat dehydration due to diarrhea or vomiting.",
        "who_can_take": "Can be used by children and adults.",
        "avoid": "Use with doctor advice in severe electrolyte imbalance or kidney issues.",
        "category": "Hydration therapy"
    },
    "vitamin d3": {
        "generic_name": "Vitamin D3",
        "uses": "Used to treat or prevent vitamin D deficiency.",
        "who_can_take": "Can be used by adults and children depending on dose.",
        "avoid": "Use carefully in hypercalcemia.",
        "category": "Supplement"
    }
}