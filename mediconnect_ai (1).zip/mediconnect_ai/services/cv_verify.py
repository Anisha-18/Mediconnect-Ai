import os
import re
import pdfplumber
import pytesseract
from PIL import Image
from rapidfuzz import process, fuzz
from services.drug_kb import DRUG_INFO

def allowed_file(filename, allowed_extensions):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_extensions

def configure_tesseract(tesseract_cmd=""):
    if tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

def extract_text_from_image(file_path):
    img = Image.open(file_path)
    text = pytesseract.image_to_string(img)
    return text.strip()

def extract_text_from_pdf(file_path):
    chunks = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            if text.strip():
                chunks.append(text)
    return "\n".join(chunks).strip()

def parse_date(text, labels):
    for label in labels:
        pattern = rf"{label}\s*[:\-]?\s*([0-9]{{1,2}}/[0-9]{{4}}|[0-9]{{2}}/[0-9]{{4}}|[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}})"
        match = re.search(pattern, text, flags=re.I)
        if match:
            return match.group(1)
    return ""

def parse_batch(text):
    match = re.search(r"(Batch\s*No|Batch)\s*[:\-]?\s*([A-Za-z0-9@#\-_\/]+)", text, flags=re.I)
    return match.group(2) if match else ""

def parse_manufacturer(text):
    match = re.search(r"(Manufacturer)\s*[:\-]?\s*([A-Za-z0-9 .,&\-]+)", text, flags=re.I)
    return match.group(2).strip() if match else ""

def detect_drug_name(text):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    joined = " ".join(lines).lower()

    match = re.search(r"Drug\s*Name\s*[:\-]?\s*([A-Za-z0-9 /().-]+)", " ".join(lines), flags=re.I)
    if match:
        candidate = match.group(1).strip()
        best = process.extractOne(candidate.lower(), list(DRUG_INFO.keys()), scorer=fuzz.partial_ratio)
        if best and best[1] >= 60:
            return best[0], candidate

    best = process.extractOne(joined, list(DRUG_INFO.keys()), scorer=fuzz.partial_ratio)
    if best and best[1] >= 60:
        return best[0], best[0].title()

    return "", ""

def verify_package_file(file_path, tesseract_cmd=""):
    configure_tesseract(tesseract_cmd)

    ext = file_path.rsplit(".", 1)[1].lower()
    raw_text = extract_text_from_pdf(file_path) if ext == "pdf" else extract_text_from_image(file_path)

    drug_key, detected_name = detect_drug_name(raw_text)
    batch_no = parse_batch(raw_text)
    mfg_date = parse_date(raw_text, ["Manufacturing Date", "MFG Date", "MFG"])
    expiry_date = parse_date(raw_text, ["Expiry Date", "EXP Date", "EXP"])
    manufacturer = parse_manufacturer(raw_text)

    info = DRUG_INFO.get(drug_key, {})
    counterfeit_probability = 0.10 if drug_key else 0.35
    if "@@" in raw_text or "9999" in raw_text:
        counterfeit_probability = 0.52

    return {
        "package_detected": True if raw_text else False,
        "raw_text": raw_text,
        "drug_name": detected_name or "Not clearly detected",
        "batch_no": batch_no or "Not found",
        "mfg_date": mfg_date or "Not found",
        "expiry_date": expiry_date or "Not found",
        "manufacturer": manufacturer or "Not found",
        "uses": info.get("uses", "Knowledge not available for this medicine."),
        "who_can_take": info.get("who_can_take", "Please consult a doctor or pharmacist."),
        "avoid": info.get("avoid", "Please consult a doctor."),
        "category": info.get("category", "Unknown"),
        "detection_confidence": 0.92 if raw_text else 0.40,
        "ocr_confidence": 0.88 if raw_text else 0.30,
        "counterfeit_probability": counterfeit_probability,
        "remarks": "Text extracted successfully." if raw_text else "Could not extract enough text from file."
    }