from rapidfuzz import fuzz

INTENTS = {
    "stockout": {
        "answer_en": "Stockout risk is detected by comparing current stock, reorder level, and forecast demand. When stock is low, the system raises alerts and can auto-generate purchase orders.",
        "answer_ta": "ஸ்டாக் குறைவு அபாயம் தற்போதைய stock, reorder level, forecast demand ஆகியவற்றை ஒப்பிட்டு கணிக்கப்படுகிறது. stock குறைந்தால் alert மற்றும் auto purchase order உருவாகும்.",
        "answer_hi": "स्टॉकआउट जोखिम current stock, reorder level और forecast demand को compare करके पता लगाया जाता है। stock कम होने पर alert और auto purchase order generate होता है।",
        "patterns_en": [
            "stockout", "shortage", "low stock", "stock risk", "medicine shortage", "stock level",
            "how shortage detected", "which medicine is low", "stock below reorder", "inventory risk"
        ],
        "patterns_ta": [
            "stock", "shortage", "stockout", "குறைவு", "மருந்து குறைவு", "ஸ்டாக் குறைவு", "reorder", "low stock",
            "எந்த medicine குறைவு", "stock risk"
        ],
        "patterns_hi": [
            "stock", "shortage", "stockout", "कम stock", "दवा कमी", "inventory risk", "reorder level",
            "कौन सी medicine कम है", "low stock", "shortage alert"
        ]
    },
    "expiry": {
        "answer_en": "Expiry monitoring checks expiry date continuously. The dashboard starts alerting from 2 days before expiry, so the pharmacy team can dispense, return, or isolate the medicine.",
        "answer_ta": "Expiry date தொடர்ந்து கண்காணிக்கப்படுகிறது. expiryக்கு 2 நாட்களுக்கு முன்பே dashboard alert காட்டும். அதனால் pharmacist medicine dispense, return அல்லது isolate செய்யலாம்.",
        "answer_hi": "Expiry date लगातार monitor की जाती है। expiry से 2 दिन पहले dashboard alert दिखाता है ताकि pharmacist medicine को dispense, return या isolate कर सके।",
        "patterns_en": [
            "expiry", "expire", "near expiry", "expiring soon", "expiry alert", "expired drug",
            "how expiry tracked", "medicine expiry", "expiry dashboard", "shelf life"
        ],
        "patterns_ta": [
            "expiry", "expire", "முடிவு தேதி", "காலாவதி", "near expiry", "expiry alert", "shelf life",
            "expiry எப்படி track", "மருந்து expiry", "dashboard alert"
        ],
        "patterns_hi": [
            "expiry", "expire", "समाप्ति", "expiry alert", "near expiry", "expiring medicine",
            "shelf life", "expiry track", "दवा expiry", "dashboard alert"
        ]
    },
    "billing": {
        "answer_en": "When billing is created for a patient, the selected medicine quantity is automatically deducted from inventory and reflected across all dashboards.",
        "answer_ta": "Patient billing செய்தவுடன் தேர்ந்தெடுக்கப்பட்ட medicine quantity inventory-இல் இருந்து தானாக குறைக்கப்படும். அந்த update எல்லா dashboard-களிலும் தெரியும்.",
        "answer_hi": "Patient billing होने पर selected medicine quantity inventory से अपने आप कम हो जाती है और यह update सभी dashboards में दिखती है।",
        "patterns_en": [
            "billing", "patient billing", "medicine bill", "invoice", "stock update after billing",
            "how billing works", "bill and stock", "patient invoice", "pharmacy bill", "sales bill"
        ],
        "patterns_ta": [
            "billing", "patient billing", "bill", "invoice", "medicine bill", "stock update", "billing எப்படி",
            "patient invoice", "pharmacy bill", "stock குறையும்"
        ],
        "patterns_hi": [
            "billing", "patient bill", "invoice", "medicine bill", "stock update after billing",
            "bill kaise", "pharmacy invoice", "patient invoice", "stock kam hoga", "sales bill"
        ]
    },
    "federated": {
        "answer_en": "Federated learning keeps hospital data local. Only privacy-preserving model updates are shared for aggregation, not raw patient or procurement records.",
        "answer_ta": "Federated learning மூலம் hospital data local-ஆவே இருக்கும். raw patient data share ஆகாது. privacy-protected model updates மட்டும் share ஆகும்.",
        "answer_hi": "Federated learning में hospital data local ही रहता है। raw patient data share नहीं होता, केवल privacy-protected model updates share होते हैं।",
        "patterns_en": [
            "federated", "privacy", "local training", "flower", "opacus", "data privacy",
            "hospital node learning", "federated learning", "model aggregation", "raw data"
        ],
        "patterns_ta": [
            "federated", "privacy", "data privacy", "flower", "opacus", "local training",
            "hospital node", "raw data", "model aggregation", "federated learning"
        ],
        "patterns_hi": [
            "federated", "privacy", "flower", "opacus", "local training", "raw data",
            "data privacy", "model aggregation", "hospital node learning", "federated learning"
        ]
    },
    "verification": {
        "answer_en": "Drug verification extracts text from uploaded image or PDF, identifies medicine name, batch, manufacturing date, expiry date, manufacturer, and maps the medicine to usage guidance.",
        "answer_ta": "Drug verification uploaded image அல்லது PDF-இலிருந்து text extract செய்து, medicine name, batch, mfg date, expiry date, manufacturer ஆகியவற்றை கண்டுபிடிக்கும். பின்னர் அதன் பயன்பாட்டையும் காட்டும்.",
        "answer_hi": "Drug verification uploaded image या PDF से text extract करके medicine name, batch, manufacturing date, expiry date और manufacturer को पहचानता है, फिर उसके use-case भी दिखाता है।",
        "patterns_en": [
            "drug verification", "ocr", "extract text", "medicine image", "pdf verify", "package verify",
            "batch detect", "mfg date detect", "expiry detect", "medicine information extract"
        ],
        "patterns_ta": [
            "drug verification", "ocr", "extract text", "medicine image", "pdf verify", "package verify",
            "batch detect", "mfg date", "expiry date", "information extract"
        ],
        "patterns_hi": [
            "drug verification", "ocr", "extract text", "medicine image", "pdf verify", "package verify",
            "batch detect", "mfg date", "expiry date", "information extract"
        ]
    }
}

# Generate many built-in questions automatically
def build_variants():
    variants = []
    for key, value in INTENTS.items():
        for p in value["patterns_en"]:
            variants.append(("en", p, value["answer_en"]))
            variants.append(("en", f"Explain {p}", value["answer_en"]))
            variants.append(("en", f"What is {p}", value["answer_en"]))
            variants.append(("en", f"How does {p} work", value["answer_en"]))
        for p in value["patterns_ta"]:
            variants.append(("ta", p, value["answer_ta"]))
            variants.append(("ta", f"{p} எப்படி", value["answer_ta"]))
            variants.append(("ta", f"{p} என்ன", value["answer_ta"]))
            variants.append(("ta", f"{p} explain", value["answer_ta"]))
        for p in value["patterns_hi"]:
            variants.append(("hi", p, value["answer_hi"]))
            variants.append(("hi", f"{p} क्या है", value["answer_hi"]))
            variants.append(("hi", f"{p} कैसे काम करता है", value["answer_hi"]))
            variants.append(("hi", f"{p} समझाओ", value["answer_hi"]))
    return variants

QA_VARIANTS = build_variants()

def detect_lang(q):
    q = q.lower()
    tamil_chars = any('\u0B80' <= ch <= '\u0BFF' for ch in q)
    devanagari = any('\u0900' <= ch <= '\u097F' for ch in q)
    if tamil_chars:
        return "ta"
    if devanagari:
        return "hi"
    return "en"

def answer_supply_query(query):
    q = query.strip().lower()
    lang = detect_lang(q)

    best_score = -1
    best_answer = None

    for v_lang, pattern, answer in QA_VARIANTS:
        score = fuzz.partial_ratio(q, pattern.lower())
        if lang == v_lang:
            score += 5
        if score > best_score:
            best_score = score
            best_answer = answer

    if best_score >= 65:
        return {
            "answer": best_answer,
            "source": "Built-in Multilingual RAG Knowledge Base",
            "confidence": round(min(best_score / 100, 0.98), 2)
        }

    fallback = {
        "en": "MediConnect AI supports billing, real-time stock updates, expiry alerts, federated forecasting, purchase order generation, and drug verification.",
        "ta": "MediConnect AI billing, real-time stock update, expiry alert, federated forecasting, purchase order generation, drug verification போன்றவற்றை support செய்கிறது.",
        "hi": "MediConnect AI billing, real-time stock update, expiry alert, federated forecasting, purchase order generation और drug verification को support करता है।"
    }

    return {
        "answer": fallback[lang],
        "source": "Fallback RAG Assistant",
        "confidence": 0.76
    }