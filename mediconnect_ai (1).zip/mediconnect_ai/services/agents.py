from models.supplier import Supplier

def pick_best_supplier(shortage_risk):
    suppliers = Supplier.query.all()

    if not suppliers:
        return {
            "name": "Default Medical Supplier",
            "lead_time_days": 3,
            "negotiated_discount": "5%"
        }

    suppliers = sorted(
        suppliers,
        key=lambda s: (-s.rating, s.lead_time_days, s.price_index)
    )
    best = suppliers[0]

    return {
        "name": best.name,
        "lead_time_days": best.lead_time_days,
        "negotiated_discount": "8%" if shortage_risk == "High" else "4%"
    }

def run_agent_workflow(medicine, quantity, hospital, current_stock, expiry_days):
    shortage_risk = "High" if current_stock < quantity else "Moderate" if current_stock < quantity * 1.5 else "Low"
    risk_score = 90 if shortage_risk == "High" else 64 if shortage_risk == "Moderate" else 28
    supplier = pick_best_supplier(shortage_risk)

    expiry_action = (
        "Urgent redistribution / priority dispensing"
        if expiry_days is not None and expiry_days <= 15 else
        "Monitor expiry and rotate batch"
        if expiry_days is not None and expiry_days <= 45 else
        "Normal shelf-life"
    )

    action = "Autonomous purchase order required" if shortage_risk in ["High", "Moderate"] else "Monitor inventory"
    po_qty = max(quantity * 2, 100) if shortage_risk != "Low" else quantity

    alerts = []
    if shortage_risk == "High":
        alerts.append(f"Critical shortage predicted for {medicine} at {hospital}.")
    if expiry_days is not None and expiry_days <= 2:
        alerts.append(f"{medicine} is expiring within 2 days.")
    elif expiry_days is not None and expiry_days <= 30:
        alerts.append(f"Near-expiry batch detected for {medicine}.")

    return {
        "medicine": medicine,
        "hospital": hospital,
        "current_stock": current_stock,
        "requested_quantity": quantity,
        "shortage_risk": shortage_risk,
        "risk_score": risk_score,
        "action": action,
        "expiry_action": expiry_action,
        "workflow_status": "Self-healed and synchronized",
        "compliance_status": "Compliant",
        "supplier_recommendation": supplier,
        "purchase_order": {
            "medicine": medicine,
            "quantity": po_qty,
            "priority": shortage_risk,
            "status": "Generated" if shortage_risk != "Low" else "Observation"
        },
        "alerts": alerts
    }