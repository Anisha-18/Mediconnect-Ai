def explain_decision(result):
    parts = []

    if result["shortage_risk"] == "High":
        parts.append(
            f"Shortage risk is High because available stock ({result['current_stock']}) is below required demand ({result['requested_quantity']})."
        )
    elif result["shortage_risk"] == "Moderate":
        parts.append("Shortage risk is Moderate because current stock is only slightly above expected need.")
    else:
        parts.append("Shortage risk is Low because stock is sufficient relative to expected demand.")

    parts.append(f"Risk score {result['risk_score']} was calculated using stock sufficiency, urgency, and supply continuity impact.")
    parts.append(f"Supplier {result['supplier_recommendation']['name']} was selected using supplier rating, lead time, and procurement suitability.")
    parts.append(f"Expiry guidance is '{result['expiry_action']}'.")

    return " ".join(parts)