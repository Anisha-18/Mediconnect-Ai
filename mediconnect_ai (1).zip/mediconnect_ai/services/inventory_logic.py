from datetime import date
from models import db
from models.alert import Alert

def reduce_stock_after_billing(inventory_item, quantity):
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero.")
    if inventory_item.stock < quantity:
        raise ValueError(f"Not enough stock for {inventory_item.medicine}. Available: {inventory_item.stock}")

    inventory_item.stock -= quantity
    db.session.add(inventory_item)

def generate_expiry_alerts(hospital_id, inventory_items):
    created = 0
    for item in inventory_items:
        if item.expiry_date:
            days_left = (item.expiry_date - date.today()).days
            if days_left <= 2:
                existing = Alert.query.filter(
                    Alert.hospital_id == hospital_id,
                    Alert.title == "Expiry Alert",
                    Alert.message.like(f"%{item.medicine}%"),
                ).first()

                if not existing:
                    severity = "High" if days_left <= 0 else "Moderate"
                    msg = f"{item.medicine} batch {item.batch_no or '-'} expires in {days_left} day(s). Immediate action required."
                    alert = Alert(
                        title="Expiry Alert",
                        message=msg,
                        severity=severity,
                        hospital_id=hospital_id
                    )
                    db.session.add(alert)
                    created += 1
    return created