from datetime import date, timedelta
from app import app
from models import db
from models.hospital import Hospital
from models.user import User
from models.inventory import Inventory
from models.supplier import Supplier
from models.alert import Alert

with app.app_context():
    db.drop_all()
    db.create_all()

    h1 = Hospital(name="Apollo North", city="Chennai", node_name="Hospital Node 1")
    h2 = Hospital(name="CityCare Central", city="Coimbatore", node_name="Hospital Node 2")
    h3 = Hospital(name="Metro Heart Institute", city="Madurai", node_name="Hospital Node 3")
    h4 = Hospital(name="GreenLife Medical", city="Trichy", node_name="Hospital Node 4")
    h5 = Hospital(name="Sunrise MultiSpeciality", city="Salem", node_name="Hospital Node 5")
    db.session.add_all([h1, h2, h3, h4, h5])
    db.session.commit()

    admin = User(full_name="System Admin", email="admin@mediconnect.com", role="admin")
    admin.set_password("admin123")

    hospital_user = User(full_name="Hospital Manager", email="hospital@mediconnect.com", role="hospital", hospital_id=h1.id)
    hospital_user.set_password("hospital123")

    pharmacist = User(full_name="Pharmacist User", email="pharma@mediconnect.com", role="pharmacist", hospital_id=h1.id)
    pharmacist.set_password("pharma123")

    db.session.add_all([admin, hospital_user, pharmacist])

    suppliers = [
        Supplier(name="MediCore Pharma", rating=4.8, lead_time_days=2, price_index=1.0, compliance_score=96),
        Supplier(name="LifeDose Labs", rating=4.5, lead_time_days=3, price_index=0.98, compliance_score=92),
        Supplier(name="HealNet Pharma", rating=4.6, lead_time_days=4, price_index=0.95, compliance_score=94)
    ]
    db.session.add_all(suppliers)

    items = [
        Inventory(
            medicine="Paracetamol 500mg",
            category="Analgesic",
            stock=180,
            reorder_level=100,
            forecast_next_week=210,
            mfg_date=date.today() - timedelta(days=150),
            expiry_date=date.today() + timedelta(days=20),
            batch_no="PAR001",
            supplier_name="MediCore Pharma",
            counterfeit_risk="Low",
            hospital_id=h1.id
        ),
        Inventory(
            medicine="Insulin Glargine",
            category="Endocrine",
            stock=48,
            reorder_level=70,
            forecast_next_week=95,
            mfg_date=date.today() - timedelta(days=120),
            expiry_date=date.today() + timedelta(days=2),
            batch_no="INS224",
            supplier_name="LifeDose Labs",
            counterfeit_risk="Medium",
            hospital_id=h1.id
        ),
        Inventory(
            medicine="Amoxicillin 250mg",
            category="Antibiotic",
            stock=92,
            reorder_level=80,
            forecast_next_week=115,
            mfg_date=date.today() - timedelta(days=100),
            expiry_date=date.today() + timedelta(days=1),
            batch_no="AMX221",
            supplier_name="HealNet Pharma",
            counterfeit_risk="Medium",
            hospital_id=h1.id
        ),
        Inventory(
            medicine="Ceftriaxone Injection",
            category="Critical Care",
            stock=20,
            reorder_level=40,
            forecast_next_week=58,
            mfg_date=date.today() - timedelta(days=60),
            expiry_date=date.today() + timedelta(days=90),
            batch_no="CEF990",
            supplier_name="MediCore Pharma",
            counterfeit_risk="Low",
            hospital_id=h1.id
        ),
    ]
    db.session.add_all(items)

    alerts = [
        Alert(title="Shortage Alert", message="Insulin Glargine is below safe stock threshold.", severity="High", hospital_id=h1.id),
        Alert(title="Expiry Alert", message="Amoxicillin 250mg expires within 2 days.", severity="Moderate", hospital_id=h1.id),
    ]
    db.session.add_all(alerts)

    db.session.commit()
    print("Database seeded successfully.")