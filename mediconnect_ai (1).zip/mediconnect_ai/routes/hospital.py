from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db
from models.inventory import Inventory
from models.purchase_order import PurchaseOrder
from models.alert import Alert
from models.billing import Billing
from models.bill_item import BillItem
from services.forecasting import build_metrics, build_chart_data
from services.agents import run_agent_workflow
from services.explainability import explain_decision
from services.inventory_logic import reduce_stock_after_billing, generate_expiry_alerts

hospital_bp = Blueprint("hospital", __name__, url_prefix="/hospital")

def hospital_only():
    return current_user.is_authenticated and current_user.role == "hospital"

@hospital_bp.route("/dashboard")
@login_required
def hospital_dashboard():
    if not hospital_only():
        return render_template("index.html")

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
    generate_expiry_alerts(current_user.hospital_id, items)

    orders = PurchaseOrder.query.filter_by(hospital_id=current_user.hospital_id).order_by(PurchaseOrder.created_at.desc()).all()
    alerts = Alert.query.filter_by(hospital_id=current_user.hospital_id).order_by(Alert.created_at.desc()).all()
    bills = Billing.query.filter_by(hospital_id=current_user.hospital_id).order_by(Billing.created_at.desc()).limit(10).all()

    metrics = build_metrics(items)
    chart_data = build_chart_data(items)

    return render_template(
        "hospital_dashboard.html",
        items=items,
        orders=orders,
        alerts=alerts,
        bills=bills,
        metrics=metrics,
        chart_data=chart_data
    )

@hospital_bp.route("/inventory", methods=["GET", "POST"])
@login_required
def inventory_page():
    if not hospital_only():
        return render_template("index.html")

    if request.method == "POST":
        mfg_date = request.form.get("mfg_date")
        expiry_date = request.form.get("expiry_date")

        item = Inventory(
            medicine=request.form.get("medicine"),
            category=request.form.get("category"),
            stock=int(request.form.get("stock")),
            reorder_level=int(request.form.get("reorder_level")),
            forecast_next_week=int(request.form.get("forecast_next_week")),
            mfg_date=datetime.strptime(mfg_date, "%Y-%m-%d").date() if mfg_date else None,
            expiry_date=datetime.strptime(expiry_date, "%Y-%m-%d").date() if expiry_date else None,
            batch_no=request.form.get("batch_no"),
            supplier_name=request.form.get("supplier_name"),
            counterfeit_risk=request.form.get("counterfeit_risk"),
            hospital_id=current_user.hospital_id
        )
        db.session.add(item)
        db.session.commit()
        flash("Inventory added successfully.", "success")
        return redirect(url_for("hospital.inventory_page"))

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
    generate_expiry_alerts(current_user.hospital_id, items)
    return render_template("inventory.html", items=items)

@hospital_bp.route("/create-po", methods=["GET", "POST"])
@login_required
def create_po():
    if not hospital_only():
        return render_template("index.html")

    result = None

    if request.method == "POST":
        inventory_id = request.form.get("inventory_id")
        quantity = int(request.form.get("quantity"))

        item = Inventory.query.filter_by(id=inventory_id, hospital_id=current_user.hospital_id).first()
        if not item:
            flash("Inventory item not found.", "danger")
            return redirect(url_for("hospital.create_po"))

        result = run_agent_workflow(
            medicine=item.medicine,
            quantity=quantity,
            hospital=current_user.hospital.name,
            current_stock=item.stock,
            expiry_days=item.expiry_days
        )

        po = PurchaseOrder(
            medicine=result["purchase_order"]["medicine"],
            quantity=result["purchase_order"]["quantity"],
            supplier_name=result["supplier_recommendation"]["name"],
            priority=result["purchase_order"]["priority"],
            status=result["purchase_order"]["status"],
            hospital_id=current_user.hospital_id
        )
        db.session.add(po)

        for text in result["alerts"]:
            db.session.add(Alert(
                title="Supply Alert",
                message=text,
                severity=result["shortage_risk"],
                hospital_id=current_user.hospital_id
            ))

        db.session.commit()
        result["explanation"] = explain_decision(result)
        flash("Autonomous purchase order generated.", "success")

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
    return render_template("create_po.html", result=result, items=items)

@hospital_bp.route("/billing", methods=["GET", "POST"])
@login_required
def billing_page():
    if not hospital_only():
        return render_template("index.html")

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()

    if request.method == "POST":
        patient_name = request.form.get("patient_name")
        patient_age = request.form.get("patient_age")
        patient_gender = request.form.get("patient_gender")
        doctor_name = request.form.get("doctor_name")
        inventory_id = int(request.form.get("inventory_id"))
        quantity = int(request.form.get("quantity"))
        unit_price = float(request.form.get("unit_price"))

        item = Inventory.query.filter_by(id=inventory_id, hospital_id=current_user.hospital_id).first()
        if not item:
            flash("Medicine not found.", "danger")
            return redirect(url_for("hospital.billing_page"))

        try:
            reduce_stock_after_billing(item, quantity)
        except ValueError as e:
            flash(str(e), "danger")
            return redirect(url_for("hospital.billing_page"))

        subtotal = quantity * unit_price

        bill = Billing(
            patient_name=patient_name,
            patient_age=int(patient_age) if patient_age else None,
            patient_gender=patient_gender,
            doctor_name=doctor_name,
            total_amount=subtotal,
            hospital_id=current_user.hospital_id
        )
        db.session.add(bill)
        db.session.flush()

        bill_item = BillItem(
            billing_id=bill.id,
            inventory_id=item.id,
            medicine_name=item.medicine,
            quantity=quantity,
            unit_price=unit_price,
            subtotal=subtotal
        )
        db.session.add(bill_item)

        if item.stock < item.reorder_level:
            db.session.add(Alert(
                title="Low Stock Alert",
                message=f"{item.medicine} stock dropped below reorder level after billing.",
                severity="High",
                hospital_id=current_user.hospital_id
            ))

        db.session.commit()
        generate_expiry_alerts(current_user.hospital_id, Inventory.query.filter_by(hospital_id=current_user.hospital_id).all())

        flash("Billing completed and stock updated.", "success")
        return redirect(url_for("hospital.billing_page"))

    recent_bills = Billing.query.filter_by(hospital_id=current_user.hospital_id).order_by(Billing.created_at.desc()).limit(10).all()
    return render_template("billing.html", items=items, recent_bills=recent_bills)