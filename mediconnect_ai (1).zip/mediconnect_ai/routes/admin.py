from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models.user import User
from models.hospital import Hospital
from models.inventory import Inventory
from models.purchase_order import PurchaseOrder
from models.alert import Alert
from models.billing import Billing
from services.forecasting import build_metrics, build_chart_data, simulate_federated_summary
from services.inventory_logic import generate_expiry_alerts

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

def admin_only():
    return current_user.is_authenticated and current_user.role == "admin"

@admin_bp.route("/dashboard")
@login_required
def admin_dashboard():
    if not admin_only():
        return render_template("index.html")

    hospitals = Hospital.query.all()
    users = User.query.all()
    inventory_items = Inventory.query.all()
    orders = PurchaseOrder.query.order_by(PurchaseOrder.created_at.desc()).limit(10).all()
    alerts = Alert.query.order_by(Alert.created_at.desc()).limit(10).all()
    bills = Billing.query.order_by(Billing.created_at.desc()).limit(10).all()

    for h in hospitals:
        generate_expiry_alerts(h.id, Inventory.query.filter_by(hospital_id=h.id).all())

    metrics = build_metrics(inventory_items)
    chart_data = build_chart_data(inventory_items)
    federated = simulate_federated_summary()

    return render_template(
        "admin_dashboard.html",
        hospitals=hospitals,
        users=users,
        inventory_items=inventory_items,
        orders=orders,
        alerts=alerts,
        bills=bills,
        metrics=metrics,
        chart_data=chart_data,
        federated=federated
    )