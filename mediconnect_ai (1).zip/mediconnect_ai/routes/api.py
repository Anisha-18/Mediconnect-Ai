import os
from flask import Blueprint, request, jsonify, current_app, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from services.rag import answer_supply_query
from services.cv_verify import allowed_file, verify_package_file
from services.reports import build_weekly_report
from services.forecasting import simulate_federated_summary, build_metrics, build_chart_data, serialize_inventory, serialize_alerts, serialize_orders
from services.inventory_logic import generate_expiry_alerts
from models.inventory import Inventory
from models.alert import Alert
from models.purchase_order import PurchaseOrder
from models.billing import Billing

api_bp = Blueprint("api", __name__)

@api_bp.route("/rag-chat")
@login_required
def rag_chat_page():
    return render_template("rag_chat.html")

@api_bp.route("/rag-chat-api", methods=["POST"])
@login_required
def rag_chat_api():
    payload = request.get_json()
    query = payload.get("query", "")
    return jsonify(answer_supply_query(query))

@api_bp.route("/verify", methods=["GET", "POST"])
@login_required
def verify():
    result = None
    uploaded_path = None

    if request.method == "POST":
        file = request.files.get("file")

        if not file or file.filename == "":
            flash("Please upload a file.", "danger")
            return redirect(url_for("api.verify"))

        if not allowed_file(file.filename, current_app.config["ALLOWED_EXTENSIONS"]):
            flash("Unsupported file format.", "danger")
            return redirect(url_for("api.verify"))

        filename = file.filename
        save_path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)

        result = verify_package_file(save_path, current_app.config.get("OCR_TESSERACT_CMD", ""))
        uploaded_path = f"uploads/{filename}"

    return render_template("verify.html", result=result, uploaded_path=uploaded_path)

@api_bp.route("/reports")
@login_required
def reports():
    if current_user.role in ["hospital", "pharmacist"]:
        items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
        bills = Billing.query.filter_by(hospital_id=current_user.hospital_id).all()
    else:
        items = Inventory.query.all()
        bills = Billing.query.all()

    report = build_weekly_report(items, bills)
    return render_template("reports.html", report=report)

@api_bp.route("/federated")
@login_required
def federated():
    summary = simulate_federated_summary()
    return render_template("federated.html", summary=summary)

@api_bp.route("/live/hospital-dashboard")
@login_required
def live_hospital_dashboard():
    if current_user.role not in ["hospital", "pharmacist"]:
        return jsonify({"error": "Unauthorized"}), 403

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
    generate_expiry_alerts(current_user.hospital_id, items)
    alerts = Alert.query.filter_by(hospital_id=current_user.hospital_id).order_by(Alert.created_at.desc()).limit(10).all()
    orders = PurchaseOrder.query.filter_by(hospital_id=current_user.hospital_id).order_by(PurchaseOrder.created_at.desc()).limit(10).all()
    bills = Billing.query.filter_by(hospital_id=current_user.hospital_id).order_by(Billing.created_at.desc()).limit(10).all()

    return jsonify({
        "metrics": build_metrics(items),
        "chart_data": build_chart_data(items),
        "inventory": serialize_inventory(items),
        "alerts": serialize_alerts(alerts),
        "orders": serialize_orders(orders),
        "bills": [{
            "patient_name": b.patient_name,
            "total_amount": b.total_amount,
            "created_at": b.created_at.strftime("%Y-%m-%d %H:%M")
        } for b in bills]
    })

@api_bp.route("/live/admin-dashboard")
@login_required
def live_admin_dashboard():
    if current_user.role != "admin":
        return jsonify({"error": "Unauthorized"}), 403

    items = Inventory.query.all()
    alerts = Alert.query.order_by(Alert.created_at.desc()).limit(10).all()
    orders = PurchaseOrder.query.order_by(PurchaseOrder.created_at.desc()).limit(10).all()
    bills = Billing.query.order_by(Billing.created_at.desc()).limit(10).all()

    return jsonify({
        "metrics": build_metrics(items),
        "chart_data": build_chart_data(items),
        "inventory": serialize_inventory(items),
        "alerts": serialize_alerts(alerts),
        "orders": serialize_orders(orders),
        "bills": [{
            "patient_name": b.patient_name,
            "total_amount": b.total_amount,
            "hospital_id": b.hospital_id,
            "created_at": b.created_at.strftime("%Y-%m-%d %H:%M")
        } for b in bills]
    })