from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models.inventory import Inventory
from models.alert import Alert
from models.billing import Billing
from services.forecasting import build_metrics
from services.inventory_logic import generate_expiry_alerts

pharmacist_bp = Blueprint("pharmacist", __name__, url_prefix="/pharmacist")

def pharmacist_only():
    return current_user.is_authenticated and current_user.role == "pharmacist"

@pharmacist_bp.route("/dashboard")
@login_required
def pharmacist_dashboard():
    if not pharmacist_only():
        return render_template("index.html")

    items = Inventory.query.filter_by(hospital_id=current_user.hospital_id).all()
    generate_expiry_alerts(current_user.hospital_id, items)

    alerts = Alert.query.filter_by(hospital_id=current_user.hospital_id).order_by(Alert.created_at.desc()).all()
    bills = Billing.query.filter_by(hospital_id=current_user.hospital_id).order_by(Billing.created_at.desc()).limit(10).all()
    metrics = build_metrics(items)

    return render_template(
        "pharmacist_dashboard.html",
        items=items,
        alerts=alerts,
        bills=bills,
        metrics=metrics
    )