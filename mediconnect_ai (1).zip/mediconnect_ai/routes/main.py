from flask import Blueprint, render_template
from flask_login import current_user

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def index():
    return render_template("index.html", current_user=current_user)

@main_bp.route("/profile")
def profile():
    return render_template("profile.html")