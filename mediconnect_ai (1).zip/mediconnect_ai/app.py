import os
from flask import Flask
from config import Config
from models import db, login_manager
from routes.main import main_bp
from routes.auth import auth_bp
from routes.admin import admin_bp
from routes.hospital import hospital_bp
from routes.pharmacist import pharmacist_bp
from routes.api import api_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    os.makedirs("instance", exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(hospital_bp)
    app.register_blueprint(pharmacist_bp)
    app.register_blueprint(api_bp)

    with app.app_context():
        db.create_all()

    return app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)